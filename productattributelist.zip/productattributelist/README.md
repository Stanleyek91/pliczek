# Product Attribute List

v1.2.5

Allows to view and select individual product attributes directly in product lists.

## Installation

_Product Attribute List_ is installed like any other module. Simply upload your archive to install it.

## License

This module is licensed under [Academic Free License (AFL 3.0)](https://opensource.org/licenses/afl-3.0.php).
